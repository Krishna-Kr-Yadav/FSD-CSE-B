import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <div className="footer">
      <small><center>&copy;2025 Design and Developed by Krishna</center></small>
    </div>
  )
}

export default Footer
